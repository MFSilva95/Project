
package org.holoeverywhere.addon;

public abstract class IAddonBase {
}
