
package com.actionbarsherlock.internal.view.menu;

import android.view.View.OnCreateContextMenuListener;

public interface ContextMenuCallbackGetter {
    public OnCreateContextMenuListener getOnCreateContextMenuListener();
}
